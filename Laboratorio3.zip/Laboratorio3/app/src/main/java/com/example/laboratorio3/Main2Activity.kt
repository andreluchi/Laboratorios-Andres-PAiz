package com.example.laboratorio3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import com.example.laboratorio3.databinding.ActivityMain2Binding
import logica.Topic

class Main2Activity : AppCompatActivity() {
    private lateinit var binding2: ActivityMain2Binding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        binding2= DataBindingUtil.setContentView(this,R.layout.activity_main2)

        info()

        binding2.comentario.setOnClickListener {

            comentario()
        }
    }



    private fun info(){
        val obIntent: Intent = intent
        val r= obIntent.getStringExtra("Code")
        val topic:Topic= Topic()
        binding2.topic=topic
        if(r== "sintomas"){
            topic.titulo="Sintomas"
            topic.subtitle= "Sintomas del coronavirus"
            topic.description="Los síntomas de coronavirus,pueden aparecer entre dos y 14 días después de estar expuesto, estos son los sintomas precursores:\n" +
                    "\n" +
                    "    Fiebre\n" +
                    "    Tos Seca\n" +
                    "    Falta de aire o dificultad para respirar\n" +
                    "    Cansancio\n" +
                    "    Goteo de la nariz\n" +
                    "    Molestias y Dolores\n" +
                    "    Dolor de garganta\n" +
                    "    Conjuntivitis\n" +
                    "    Diarrea y Vómitos\n"

        }
        else if (r== "evitar"){
            topic.titulo="Como Evitarlo"
            topic.subtitle= "Precauciones para el coronavirus"
            topic.description="No existe una vacuna para evitar el coronavirus, por lo cual las medidas deben de ser tomadas antes de la infeccion. Se debe de evitar cualquier liquido corporal de cualquier otro individuo. Las siguientes precauciones son recomendadas:\n" +
                    "\n" +
                    "Lávese las manos con frecuencia. Use agua y jabón o un desinfectante de manos a base de alcohol.\n" +
                    "\n" +
                    "Manténgase a una distancia segura de cualquier persona que tosa o estornude.\n" +
                    "\n" +
                    " No se toque los ojos, la nariz o la boca.\n" +
                    "\n" +
                    "Cuando tosa o estornude, cúbrase la nariz y la boca con el codo flexionado o con un pañuelo.\n" +
                    "\n" +
                    "Recordar que existen infectados que son asintomaticos.\n" +
                    "\n" +
                    "Si tiene fiebre, tos y dificultad para respirar, solicite atención médica. Llame con antelación.\n" +
                    "\n" +
                    "Utilizar su mascarilla cuando salga de casa, estando seguro de como utilizarla.\n" +
                    "\n" +
                    "Evitar las visitas innecesarias a los centros de atención médica permite que los sistemas sanitarios funcionen con mayor eficacia, lo que redunda en su protección y en la de los demás. "



        }

        else if( r=="virus"){
            topic.titulo="Coronavirus"
            topic.subtitle= "Que es el coronavirus?"
            topic.description="Los coronavirus son una familia de virus que se descubrió en la década de los 60 pero cuyo origen es todavía desconocido. Sus diferentes tipos provocan distintas enfermedades, desde un resfriado hasta un síndrome respiratorio grave (una forma grave de neumonía).\n" +
                    "\n" +
                    "Gran parte de los coronavirus no son peligrosos y se pueden tratar de forma eficaz. De hecho, la mayoría de las personas contraen en algún momento de su vida un coronavirus, generalmente durante su infancia. Aunque son más frecuentes en otoño o invierno, se pueden adquirir en cualquier época del año.\n" +
                    "\n" +
                    "El coronavirus debe su nombre al aspecto que presenta, ya que es muy parecido a una corona o un halo. Se trata de un tipo de virus presente sobre todo en los animales, pero también en los humanos."


        }



    }

    private fun comentario(){
        val comentario= binding2.comentar.text.toString()
        val clave= "r"
        val intent: Intent = Intent(this, MainActivity::class.java)
        intent.putExtra("comentari",comentario)
        intent.putExtra("c",clave)
        startActivity(intent)



    }
}
