package com.example.laboratorio3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.example.laboratorio3.databinding.ActivityMainBinding
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding :ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= DataBindingUtil.setContentView(this,R.layout.activity_main)

        binding.Prueba.setOnClickListener{

            verificar()

        }
        binding.sintomas.setOnClickListener {

            sintomas()
        }
        binding.evitar.setOnClickListener {
            precauciones()
        }

        binding.virus.setOnClickListener {
            virus()
        }

        val obIntent: Intent = intent
        val key= obIntent.getStringExtra("c")
        if(key=="r"){
            val valor= obIntent.getStringExtra("comentari")
            Toast.makeText(this, valor, Toast.LENGTH_SHORT).show()


        }

    }

    private fun verificar(){

        val estado= binding.status
        val nombre= binding.nombre.text.toString()
        val edad= binding.edad.text.toString().toInt()
        when(edad){
            in 15..40 -> estado.text= nombre+" No se encuentra en la zona de peligro pero debe tomar precauciones por sus familiares o amigos."
            in 41..60-> estado.text= nombre+" Se encuentra en un leve peligro dada su edad, es importante revisar sus condiciones o enfermedades que puedan empeorar su situacion"
            in 61..100-> estado.text= nombre+" Dado que es de la tercera edad debe de tener mucho cuidado y tomar pocos riesgos con el coronavirus. Se encuentra en grave peligro."

        }


        binding.edad.visibility= View.GONE
        binding.nombre.visibility= View.GONE
        binding.Prueba.visibility=View.GONE
        binding.textView3.visibility=View.GONE
        binding.textView4.visibility=View.GONE
        binding.status.visibility=View.VISIBLE


    }
    private fun sintomas(){
        val code= "sintomas"
        val intent: Intent = Intent(this, Main2Activity::class.java)
        intent.putExtra("Code",code)
        startActivity(intent)
    }
    private fun precauciones(){
        val code= "evitar"
        val intent: Intent = Intent(this, Main2Activity::class.java)
        intent.putExtra("Code",code)
        startActivity(intent)
    }

    private fun virus(){
        val code= "virus"
        val intent: Intent = Intent(this, Main2Activity::class.java)
        intent.putExtra("Code",code)
        startActivity(intent)
    }
}




